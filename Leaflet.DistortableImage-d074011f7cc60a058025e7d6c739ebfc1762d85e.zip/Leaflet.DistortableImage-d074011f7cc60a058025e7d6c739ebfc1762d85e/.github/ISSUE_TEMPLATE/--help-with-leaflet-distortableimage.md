---
name: "\U0001F4D6 Help with Leaflet.DistortableImage"
about: File a question
title: ''
assignees: ''

---

<!-- Please fill out as much of the template as you can -->

<!-- Start below this comment. -->


**Scope**:
API, documentation, installation, code, meta, other?


**Description**:
Feel free to include any applicable: code, screenshots, or gifs.


<!-- End. -->

<!--
Thank you! Your help makes Public Lab better. We *deeply* appreciate your helping refine and improve Leaflet.DistortableImage.

To learn how to write really great issues, which increases the chances they'll be resolved, see:
https://publiclab.org/wiki/developers#Contributing+for+non-coders
-->
