---
name: "\U0001F9E8 Feature request"
about: Suggest an idea for this project
title: ''
labels: feature
assignees: ''

---

<!-- Please fill out as much of the template as you can -->

<!-- Start below this comment. -->


**Please describe the desired behavior.**
Describe the solution you'd like.


**Additional context (optional)**
Feel free to include any applicable: code, screenshots, or gifs.


<!-- End. -->

<!--
Thank you! Your help makes Public Lab better. We *deeply* appreciate your helping refine and improve Leaflet.DistortableImage.

To learn how to write really great issues, which increases the chances they'll be resolved, see:
https://publiclab.org/wiki/developers#Contributing+for+non-coders
-->
